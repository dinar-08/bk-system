<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('monitoring', function (Blueprint $table) {
            $table->id();

            $table->foreignId('laporan_id')
                ->constrained('laporan')
                ->cascadeOnDelete();

            $table->string('nip');
            $table->foreign('nip')
                ->references('nip')->on('guru_bk')
                ->cascadeOnDelete();

            $table->date('tanggal_monitoring');
            $table->time('waktu_monitoring')->nullable();

            $table->date('tanggal_monitoring_berikutnya')->nullable();
            $table->time('waktu_monitoring_berikutnya')->nullable();

            $table->integer('monitoring_ke');

            $table->enum('status_monitoring', [
                'Terjadwal',
                'Selesai',
            ])->default('Selesai');

            $table->enum('status_perkembangan', [
                'Membaik',
                'Stabil',
                'Menurun',
            ]);

            $table->text('catatan_perkembangan');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('monitoring');
    }
};
