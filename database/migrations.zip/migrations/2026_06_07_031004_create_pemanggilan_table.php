<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pemanggilan', function (Blueprint $table) {
            $table->id();

            $table->foreignId('laporan_id')
                ->constrained('laporan')
                ->cascadeOnDelete();

            $table->string('nip')->nullable();
            $table->foreign('nip')
                ->references('nip')->on('guru_bk')
                ->nullOnDelete();

            $table->date('tanggal_pemanggilan');

            $table->time('waktu_pemanggilan');

            $table->enum('pihak_dipanggil', [
                'Siswa',
                'Orang Tua',
                'Siswa & Orang Tua',
            ]);

            $table->text('tujuan');

            $table->enum('status_kehadiran', [
                'Belum',
                'Hadir',
                'Tidak Hadir',
            ])->default('Belum');

            $table->enum('tindak_lanjut', [
                'Belum',
                'Monitoring',
                'Selesai',
            ])->default('Belum');

            $table->date('tanggal_monitoring')->nullable();

            $table->text('catatan')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pemanggilan');
    }
};
